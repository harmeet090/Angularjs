import { Component } from '@angular/core';

@Component({
  selector: 'dashboard',
  template: `
    <div>
      <h2>Dashboard</h2>
    </div>
  `
})
export class DashboardComponent {}
