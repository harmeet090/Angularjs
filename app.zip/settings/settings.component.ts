import { Component } from '@angular/core';

@Component({
  selector: 'settings',
  template: `
    <div>
      <h2>Settings</h2>
    </div>
  `
})
export class SettingsComponent {}
